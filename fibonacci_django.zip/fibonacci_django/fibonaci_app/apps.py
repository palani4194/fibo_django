from django.apps import AppConfig


class FibonaciAppConfig(AppConfig):
    name = 'fibonaci_app'

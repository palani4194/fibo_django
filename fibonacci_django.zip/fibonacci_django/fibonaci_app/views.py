from django.shortcuts import render
import time
from django.template import RequestContext
from django.http import HttpResponse, HttpResponseRedirect
from fibonaci_app.models import FibonacciInputs

# Create your views here.

# logic of fibaonacci series

def fibonacci_calculation(num):

    first_num, second_num = 1, 1
    for _ in range(1,num):
      first_num, second_num = second_num, first_num+second_num
    return first_num

# 1,1,2,3,5,8,13,21,34,55

# time time_calculation of fibonacci_calculation

def fibonacci_number(request):
    fibo_range_int = 0
    result = 0
    time_calculation = 0

    if request.GET.get('fibo_range'):
        start_time = time.time()
        fibo_range = request.GET.get('fibo_range')
        fibo_range_int = int(fibo_range)
        result = fibonacci_calculation(fibo_range_int)
        # import pdb; pdb.set_trace()
        time_calculation = str(time.time() - start_time)[0:4]


        obj = FibonacciInputs.objects.create(fibo_number=fibo_range_int, result=result, time_calculation=time_calculation)
        obj.save()

# Render into html templates

    return render(
        request,
        'index.html',
        {
            'fibo_number': fibo_range_int,
            'result': result,
            'time_calculation': time_calculation
        }
    )

from django.urls import path
from . import views

urlpatterns = [
    path('', views.fibonacci_number, name='fibonacci_number'),

]
